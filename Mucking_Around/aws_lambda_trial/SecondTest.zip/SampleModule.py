def square_root_it(x):
    return (x*x)
