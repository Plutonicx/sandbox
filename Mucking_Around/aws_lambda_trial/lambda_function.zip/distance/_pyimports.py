from ._fastcomp import *
from ._lcsubstrings import *
from ._levenshtein import *
from ._simpledists import *
from ._iterators import *
